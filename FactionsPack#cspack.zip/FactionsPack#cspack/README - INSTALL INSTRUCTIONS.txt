//// READ ME ////

== CONSTRUCTION SITES 0.9 AND UP ==

To install, simply place this package (the whole folder, the one ending in #cspack) in your plugins folder and restart your server. The folder will be deleted and the files will be installed. OR, you can use /con install (packagename) and install it manually.

Add the build sites (listed in “Information.txt”) as you normally would.

== CONSTRUCTION SITES 0.8 AND BELOW ==

Copy and paste the schematics inside WorldEdit/Schematics, except for those ending in -(number)-(number)-(number). Well, technically you could have them in there, but they wouldn’t do anything since they are stages, a feature which is 0.9+ only.